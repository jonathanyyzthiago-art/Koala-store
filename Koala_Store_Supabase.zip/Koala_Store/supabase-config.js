// COLE AQUI os dados públicos do seu projeto Supabase.
// Não coloque a service_role key neste arquivo.
window.KOALA_SUPABASE_URL = '';
window.KOALA_SUPABASE_KEY = '';
